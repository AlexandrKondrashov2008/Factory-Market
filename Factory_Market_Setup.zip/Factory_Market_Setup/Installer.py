"""
Factory Market - Установщик приложения
Windows Installer на Python
Устанавливает ярлык на рабочий стол, все файлы на диск C:
"""

import os
import sys
import json
import shutil
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import winreg as reg
import ctypes
import subprocess
import zipfile
import datetime
import tempfile
import traceback

class FactoryMarketInstaller:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Factory Market - Установщик")
        self.root.geometry("800x650")
        self.root.resizable(True, True)
        self.root.minsize(800, 650)
        
        self.root.withdraw()
        
        try:
            self.root.iconbitmap(default='icon.ico')
        except:
            pass
        
        self.app_name = "Factory Market"
        self.app_version = "1.0.0"
        self.publisher = "Factory Games"
        
        self.desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        self.install_dir = tk.StringVar(value="C:\\Factory Market")
        
        self.create_desktop_shortcut = tk.BooleanVar(value=True)
        self.create_start_menu_shortcut = tk.BooleanVar(value=True)
        self.create_uninstaller = tk.BooleanVar(value=True)
        self.optimize_for_speed = tk.BooleanVar(value=True)
        
        self.installer_dir = os.path.dirname(os.path.abspath(__file__))
        self.app_source_file = os.path.join(self.installer_dir, "Game_Launcher.py")
        self.icon_file = os.path.join(self.installer_dir, "icon.ico")
        
        self.setup_styles()
        self.create_custom_styles()
        self.create_main_container()
        self.create_widgets()
        
        self.center_window()
        self.root.deiconify()
    
    def create_main_container(self):
        """Создание основного контейнера с прокруткой"""
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill="both", expand=True)
        
        self.canvas = tk.Canvas(self.main_frame, bg=self.bg_color, highlightthickness=0)
        self.canvas.pack(side="left", fill="both", expand=True)
        
        scrollbar = ttk.Scrollbar(self.main_frame, orient="vertical", command=self.canvas.yview)
        scrollbar.pack(side="right", fill="y")
        
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.content_frame = ttk.Frame(self.canvas, style="TFrame")
        self.content_frame_id = self.canvas.create_window((0, 0), window=self.content_frame, anchor="nw")
        
        self.content_frame.bind("<Configure>", self.on_frame_configure)
        self.canvas.bind("<Configure>", self.on_canvas_configure)
        self.canvas.bind_all("<MouseWheel>", self.on_mousewheel)
    
    def on_frame_configure(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
    
    def on_canvas_configure(self, event):
        canvas_width = event.width
        self.canvas.itemconfig(self.content_frame_id, width=canvas_width)
    
    def on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
    
    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        self.bg_color = "#1a1a1a"
        self.fg_color = "#ffffff"
        self.accent_color = "#4CAF50"
        self.secondary_color = "#2196F3"
        
        self.root.configure(bg=self.bg_color)
        
        style.configure("Title.TLabel",
                       background=self.bg_color,
                       foreground=self.accent_color,
                       font=("Arial", 18, "bold"))
        
        style.configure("Subtitle.TLabel",
                       background=self.bg_color,
                       foreground=self.fg_color,
                       font=("Arial", 10))
        
        style.configure("Frame.TLabelframe",
                       background=self.bg_color,
                       foreground=self.fg_color)
        
        style.configure("Frame.TLabelframe.Label",
                       background=self.bg_color,
                       foreground=self.accent_color,
                       font=("Arial", 10, "bold"))
        
        style.configure("Info.TLabel",
                       background="#252525",
                       foreground="#aaaaaa",
                       font=("Arial", 9),
                       padding=5)
        
        style.configure("TFrame", background=self.bg_color)
    
    def create_custom_styles(self):
        style = ttk.Style()
        
        style.configure("Primary.TButton",
                      background="#4CAF50",
                      foreground="white",
                      font=("Arial", 10, "bold"),
                      padding=12)
        style.map("Primary.TButton",
                 background=[("active", "#45a049")])
        
        style.configure("Secondary.TButton",
                       background="#2196F3",
                       foreground="white",
                       font=("Arial", 9),
                       padding=8)
        style.map("Secondary.TButton",
                 background=[("active", "#1976D2")])
        
        style.configure("Cancel.TButton",
                       background="#f44336",
                       foreground="white",
                       font=("Arial", 9),
                       padding=8)
        style.map("Cancel.TButton",
                 background=[("active", "#d32f2f")])
        
        style.configure("Accent.TButton",
                       background="#FF9800",
                       foreground="white",
                       font=("Arial", 9),
                       padding=6)
        style.map("Accent.TButton",
                 background=[("active", "#F57C00")])
        
        style.configure("Custom.TCheckbutton",
                       background="#252525",
                       foreground="#ffffff")
        style.map("Custom.TCheckbutton",
                 background=[("active", "#252525")])
    
    def center_window(self):
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def create_widgets(self):
        header_frame = ttk.Frame(self.content_frame)
        header_frame.pack(fill="x", padx=30, pady=(30, 15))
        
        logo_frame = ttk.Frame(header_frame)
        logo_frame.pack(anchor="w")
        
        ttk.Label(logo_frame, text="[FM]", font=("Arial", 28), 
                 foreground=self.accent_color).pack(side="left", padx=(0, 10))
        
        title_frame = ttk.Frame(logo_frame)
        title_frame.pack(side="left")
        
        ttk.Label(title_frame, text=self.app_name, style="Title.TLabel").pack(anchor="w")
        ttk.Label(title_frame, text="Игровой лаунчер - установка", 
                 style="Subtitle.TLabel").pack(anchor="w")
        
        ttk.Label(header_frame, text=f"Версия {self.app_version}",
                 style="Subtitle.TLabel").pack(anchor="e")
        
        ttk.Separator(self.content_frame, orient='horizontal').pack(fill="x", padx=30, pady=15)
        
        location_frame = ttk.LabelFrame(self.content_frame, text=" РАЗМЕЩЕНИЕ ФАЙЛОВ ", 
                                 style="Frame.TLabelframe")
        location_frame.pack(fill="x", padx=30, pady=10)
        
        info_text = f"""
        Приложение будет установлено следующим образом:
        
        • Полная установка (все файлы):
          {self.install_dir.get()}
          
        • Ярлык на рабочем столе:
          {self.desktop_path}\\Factory Market.lnk
          
        • Иконка приложения будет ТОЛЬКО в папке установки
          
        Приложение будет доступно сразу с рабочего стола!
        """
        
        ttk.Label(location_frame, text=info_text,
                 style="Subtitle.TLabel", justify="left").pack(anchor="w", padx=20, pady=(15, 10))
        
        install_frame = ttk.LabelFrame(self.content_frame, text=" ПАПКА УСТАНОВКИ ", 
                                 style="Frame.TLabelframe")
        install_frame.pack(fill="x", padx=30, pady=10)
        
        ttk.Label(install_frame, 
                 text="Все файлы приложения будут установлены по пути:",
                 style="Subtitle.TLabel").pack(anchor="w", padx=20, pady=(15, 10))
        
        entry_frame = ttk.Frame(install_frame)
        entry_frame.pack(fill="x", padx=20, pady=(0, 15))
        
        self.install_entry = ttk.Entry(entry_frame, textvariable=self.install_dir, 
                                  font=("Arial", 10), width=60)
        self.install_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))
        
        ttk.Button(entry_frame, text="Изменить...", 
                  command=self.browse_install_directory,
                  style="Accent.TButton").pack(side="right")
        
        options_frame = ttk.LabelFrame(self.content_frame, text=" НАСТРОЙКИ УСТАНОВКИ ", 
                                      style="Frame.TLabelframe")
        options_frame.pack(fill="x", padx=30, pady=10)
        
        ttk.Checkbutton(options_frame, text="Создать ярлык на рабочем столе",
                       variable=self.create_desktop_shortcut,
                       style="Custom.TCheckbutton").pack(anchor="w", padx=20, pady=8)
        
        ttk.Checkbutton(options_frame, text="Добавить в меню 'Пуск'",
                       variable=self.create_start_menu_shortcut,
                       style="Custom.TCheckbutton").pack(anchor="w", padx=20, pady=8)
        
        ttk.Checkbutton(options_frame, text="Создать деинсталлятор",
                       variable=self.create_uninstaller,
                       style="Custom.TCheckbutton").pack(anchor="w", padx=20, pady=8)
        
        progress_frame = ttk.Frame(self.content_frame)
        progress_frame.pack(fill="x", padx=30, pady=20)
        
        self.progress_var = tk.StringVar(value="Готов к установке...")
        self.progress_label = ttk.Label(progress_frame, textvariable=self.progress_var,
                                       style="Subtitle.TLabel")
        self.progress_label.pack(pady=(0, 5))
        
        self.progress_bar = ttk.Progressbar(progress_frame, mode='determinate', length=400)
        self.progress_bar.pack(pady=(0, 10))
        
        button_frame = ttk.Frame(self.content_frame)
        button_frame.pack(fill="x", padx=30, pady=(0, 30))
        
        left_button_frame = ttk.Frame(button_frame)
        left_button_frame.pack(side="left", fill="y")
        
        ttk.Button(left_button_frame, text=" Отмена ", 
                  command=self.cancel_installation,
                  style="Cancel.TButton").pack(side="left", padx=(0, 10))
        
        ttk.Button(left_button_frame, text=" Лицензионное соглашение ",
                  command=self.show_license,
                  style="Secondary.TButton").pack(side="left")
        
        right_button_frame = ttk.Frame(button_frame)
        right_button_frame.pack(side="right", fill="y")
        
        self.install_button = ttk.Button(right_button_frame, 
                                       text=" Установить ", 
                                       command=self.start_installation,
                                       style="Primary.TButton",
                                       width=25)
        self.install_button.pack()
    
    def browse_install_directory(self):
        initial_dir = "C:\\"
        if os.path.exists(initial_dir):
            folder = filedialog.askdirectory(
                title="Выберите папку для установки Factory Market",
                initialdir=initial_dir
            )
        else:
            folder = filedialog.askdirectory(
                title="Выберите папку для установки Factory Market"
            )
        
        if folder:
            self.install_dir.set(folder)
    
    def show_license(self):
        license_text = """
        ЛИЦЕНЗИОННОЕ СОГЛАШЕНИЕ
        
        1. Права на использование
        Вы получаете право использовать Factory Market на одном компьютере.
        
        2. Сбор данных
        Приложение собирает анонимную статистику использования.
        Персональные данные не собираются.
        
        3. Ответственность
        Разработчик не несет ответственность за возможные неполадки
        в работе системы, вызванные установкой приложения.
        
        4. Техническая поддержка
        Техническая поддержка предоставляется через официальный сайт.
        
        5. Изменения условий
        Условия лицензионного соглашения могут быть изменены
        в новых версиях приложения.
        
        Нажимая "Установить", вы соглашаетесь с условиями.
        """
        
        license_window = tk.Toplevel(self.root)
        license_window.title("Лицензионное соглашение")
        license_window.geometry("600x400")
        license_window.resizable(True, True)
        license_window.configure(bg=self.bg_color)
        license_window.transient(self.root)
        license_window.grab_set()
        
        license_window.update_idletasks()
        width = license_window.winfo_width()
        height = license_window.winfo_height()
        x = (license_window.winfo_screenwidth() // 2) - (width // 2)
        y = (license_window.winfo_screenheight() // 2) - (height // 2)
        license_window.geometry(f'{width}x{height}+{x}+{y}')
        
        text_frame = tk.Frame(license_window, bg="#252525")
        text_frame.pack(fill="both", expand=True, padx=15, pady=15)
        
        text_widget = tk.Text(text_frame, bg="#252525", fg="#ffffff",
                             font=("Arial", 10), wrap="word", padx=15, pady=15)
        text_widget.insert("1.0", license_text)
        text_widget.config(state="disabled")
        
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        text_widget.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        button_frame = tk.Frame(license_window, bg=self.bg_color)
        button_frame.pack(fill="x", pady=(0, 15))
        
        ttk.Button(button_frame, text="Закрыть",
                  command=license_window.destroy,
                  style="Primary.TButton").pack()
    
    def cancel_installation(self):
        if messagebox.askyesno("Отмена", "Вы уверены, что хотите отменить установку?"):
            self.root.destroy()
    
    def start_installation(self):
        if not os.path.exists(self.app_source_file):
            messagebox.showerror("Ошибка", 
                               f"Не найден исходный файл Game_Launcher.py\n"
                               f"Путь: {self.app_source_file}")
            return
        
        install_path = self.install_dir.get()
        
        if os.path.exists(install_path):
            response = messagebox.askyesno("Папка существует", 
                f"Папка '{install_path}' уже существует.\nХотите перезаписать содержимое?")
            if not response:
                return
        
        desktop_shortcut = os.path.join(self.desktop_path, "Factory Market.lnk")
        if os.path.exists(desktop_shortcut):
            response = messagebox.askyesno("Ярлык существует", 
                f"Ярлык 'Factory Market.lnk' уже существует на рабочем столе.\nЗаменить его?")
            if not response:
                return
        
        self.install_button.config(state="disabled")
        self.progress_label.pack(pady=(15, 5))
        self.progress_bar.pack(pady=(0, 20))
        self.progress_var.set("Начинаю установку...")
        self.progress_bar["value"] = 5
        self.root.update()
        
        import threading
        thread = threading.Thread(target=self.installation_thread, daemon=True)
        thread.start()
    
    def installation_thread(self):
        try:
            install_path = self.install_dir.get()
            
            # Шаг 1: Создание папки установки
            self.root.after(0, lambda: self.progress_var.set("Создаю папку установки..."))
            self.root.after(0, lambda: self.progress_bar.config(value=10))
            self.create_install_folders(install_path)
            
            # Шаг 2: Копирование иконки
            self.root.after(0, lambda: self.progress_var.set("Копирую иконку..."))
            self.root.after(0, lambda: self.progress_bar.config(value=15))
            icon_path = self.copy_icon_to_install(install_path)
            
            # Шаг 3: Установка pyinstaller
            self.root.after(0, lambda: self.progress_var.set("Проверяю наличие pyinstaller..."))
            self.root.after(0, lambda: self.progress_bar.config(value=20))
            self.install_pyinstaller()
            
            # Шаг 4: Компиляция приложения
            self.root.after(0, lambda: self.progress_var.set("Компилирую приложение..."))
            self.root.after(0, lambda: self.progress_bar.config(value=50))
            exe_path = self.compile_application(install_path, icon_path)
            
            if not exe_path:
                raise Exception("Не удалось скомпилировать приложение")
            
            # Шаг 5: Создание ярлыков
            self.root.after(0, lambda: self.progress_var.set("Создаю ярлыки..."))
            self.root.after(0, lambda: self.progress_bar.config(value=70))
            
            # ВАЖНО: Добавляем .exe к пути если его нет
            if not exe_path.endswith('.exe'):
                exe_path_with_exe = exe_path + '.exe'
                if os.path.exists(exe_path_with_exe):
                    exe_path = exe_path_with_exe
                else:
                    # Пробуем найти EXE в dist папке
                    exe_in_dist = os.path.join(install_path, "dist", "Factory Market.exe")
                    if os.path.exists(exe_in_dist):
                        exe_path = exe_in_dist
            
            print(f"[INFO] Итоговый путь к EXE: {exe_path}")
            
            # Проверяем что EXE существует и работает
            if not os.path.exists(exe_path):
                print(f"[ERROR] EXE файл не найден: {exe_path}")
                raise Exception(f"EXE файл не был создан: {exe_path}")
            
            # Проверяем размер EXE файла
            exe_size = os.path.getsize(exe_path)
            print(f"[INFO] Размер EXE файла: {exe_size / (1024*1024):.2f} MB")
            
            # Ярлык на рабочем столе
            desktop_shortcut_created = False
            if self.create_desktop_shortcut.get():
                desktop_shortcut_created = self.create_desktop_shortcut_func(exe_path, install_path, icon_path)
            
            # Ярлык в меню "Пуск"
            start_menu_shortcut_created = False
            if self.create_start_menu_shortcut.get():
                start_menu_shortcut_created = self.create_start_menu_shortcut_func(exe_path, install_path, icon_path)
            
            # Шаг 6: Деинсталлятор
            if self.create_uninstaller.get():
                self.root.after(0, lambda: self.progress_var.set("Создаю деинсталлятор..."))
                self.root.after(0, lambda: self.progress_bar.config(value=85))
                self.create_uninstaller_func(install_path, exe_path)
            
            # Шаг 7: Регистрация
            self.root.after(0, lambda: self.progress_var.set("Регистрирую приложение..."))
            self.root.after(0, lambda: self.progress_bar.config(value=95))
            self.register_in_registry(install_path, exe_path, desktop_shortcut_created)
            
            # Шаг 8: Завершение
            self.root.after(0, lambda: self.progress_var.set("Завершаю установку..."))
            self.root.after(0, lambda: self.progress_bar.config(value=100))
            
            self.root.after(1000, lambda: self.show_success_message(install_path, exe_path, desktop_shortcut_created))
            
        except Exception as e:
            self.root.after(0, lambda: self.show_error_message(str(e) + "\n" + traceback.format_exc()))
    
    def copy_icon_to_install(self, install_path):
        try:
            if os.path.exists(self.icon_file):
                install_icon = os.path.join(install_path, "icon.ico")
                shutil.copy2(self.icon_file, install_icon)
                print(f"[OK] Иконка скопирована: {install_icon}")
                return install_icon
            else:
                print("[WARNING] Иконка не найдена")
                return None
        except Exception as e:
            print(f"[ERROR] Ошибка копирования иконки: {e}")
            return None
    
    def install_pyinstaller(self):
        try:
            import PyInstaller
            print("[OK] PyInstaller уже установлен")
        except ImportError:
            print("[INFO] Устанавливаю PyInstaller...")
            self.root.after(0, lambda: self.progress_var.set("Устанавливаю PyInstaller..."))
            
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                print("[OK] PyInstaller установлен")
            except Exception as e:
                print(f"[ERROR] Не удалось установить PyInstaller: {e}")
                raise Exception(f"Не удалось установить PyInstaller. Установите его вручную: pip install pyinstaller")
    
    def compile_application(self, install_path, icon_path):
        """Компиляция Python-кода в EXE - УЛУЧШЕННАЯ ВЕРСИЯ"""
        try:
            print(f"[INFO] Компиляция из: {self.app_source_file}")
            print(f"[INFO] EXE будет создан в: {install_path}")
            
            # Проверяем наличие исходного файла
            if not os.path.exists(self.app_source_file):
                print(f"[ERROR] Исходный файл не найден: {self.app_source_file}")
                return None
            
            # Проверяем размер исходного файла
            source_size = os.path.getsize(self.app_source_file)
            print(f"[INFO] Размер исходного кода: {source_size / 1024:.1f} KB")
            
            # Путь к EXE
            exe_name = "Factory Market"
            exe_path = os.path.join(install_path, f"{exe_name}.exe")
            
            # Проверяем, не был ли уже создан EXE ранее
            if os.path.exists(exe_path):
                print(f"[INFO] EXE уже существует, удаляю: {exe_path}")
                os.remove(exe_path)
            
            # Создаем временную папку для сборки
            temp_dir = tempfile.mkdtemp()
            print(f"[INFO] Временная папка: {temp_dir}")
            
            # Копируем исходные файлы во временную папку
            temp_source = os.path.join(temp_dir, "Game_Launcher.py")
            shutil.copy2(self.app_source_file, temp_source)
            
            if os.path.exists(self.icon_file):
                temp_icon = os.path.join(temp_dir, "icon.ico")
                shutil.copy2(self.icon_file, temp_icon)
            
            # Параметры компиляции
            pyinstaller_args = [
                sys.executable, "-m", "PyInstaller",
                "--onefile",
                "--windowed",
                "--name", exe_name,
                "--distpath", install_path,
                "--workpath", os.path.join(temp_dir, "build"),
                "--specpath", os.path.join(temp_dir, "spec"),
                "--noconfirm",
                "--clean",
                "--add-data", f"{temp_icon if os.path.exists(self.icon_file) else ''};." if os.path.exists(self.icon_file) else "",
                "--hidden-import", "tkinter",
                "--hidden-import", "PIL",
                "--hidden-import", "PIL._tkinter_finder",
                "--hidden-import", "PIL.Image",
                "--hidden-import", "PIL.ImageTk"
            ]
            
            # Добавляем иконку
            if os.path.exists(self.icon_file):
                pyinstaller_args.extend(["--icon", temp_icon])
                print(f"[INFO] Использую иконку: {temp_icon}")
            
            # Удаляем пустые аргументы
            pyinstaller_args = [arg for arg in pyinstaller_args if arg]
            
            # Добавляем исходный файл в конец
            pyinstaller_args.append(temp_source)
            
            print(f"[INFO] Команда компиляции:")
            print(" ".join(pyinstaller_args))
            
            self.root.after(0, lambda: self.progress_var.set("Идет компиляция..."))
            
            # Запускаем компиляцию
            try:
                result = subprocess.run(
                    pyinstaller_args,
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='ignore',
                    timeout=300  # 5 минут таймаут
                )
            except subprocess.TimeoutExpired:
                print("[ERROR] Компиляция превысила время ожидания")
                # Пробуем создать простой EXE
                return self.create_simple_exe(install_path)
            
            print(f"[INFO] Код завершения компиляции: {result.returncode}")
            
            if result.returncode != 0:
                print(f"[ERROR] Ошибка компиляции:")
                if result.stdout:
                    print(f"STDOUT:\n{result.stdout[:500]}")
                if result.stderr:
                    print(f"STDERR:\n{result.stderr[:500]}")
                
                # Пробуем альтернативный метод компиляции
                return self.compile_alternative(install_path, icon_path)
            
            # Проверяем что EXE создан
            expected_exe_path = os.path.join(install_path, f"{exe_name}.exe")
            
            if os.path.exists(expected_exe_path):
                # Проверяем что EXE запускается
                try:
                    exe_size = os.path.getsize(expected_exe_path)
                    print(f"[OK] EXE создан: {expected_exe_path}")
                    print(f"[INFO] Размер EXE: {exe_size / (1024*1024):.2f} MB")
                    
                    # Очищаем временные файлы
                    try:
                        shutil.rmtree(temp_dir)
                        print("[INFO] Временные файлы удалены")
                    except:
                        pass
                    
                    return expected_exe_path
                except Exception as e:
                    print(f"[ERROR] EXE создан, но есть проблемы: {e}")
                    return expected_exe_path
            else:
                # Проверяем другие возможные пути
                possible_paths = [
                    os.path.join(install_path, "dist", f"{exe_name}.exe"),
                    os.path.join(install_path, f"{exe_name}"),
                    exe_path
                ]
                
                for possible_path in possible_paths:
                    if os.path.exists(possible_path):
                        print(f"[INFO] Найден EXE по альтернативному пути: {possible_path}")
                        return possible_path
                
                print("[WARNING] EXE не найден ни в одном из ожидаемых мест")
                return self.compile_alternative(install_path, icon_path)
                
        except Exception as e:
            print(f"[ERROR] Ошибка при компиляции: {e}")
            traceback.print_exc()
            return self.compile_alternative(install_path, icon_path)
    
    def compile_alternative(self, install_path, icon_path):
        """Альтернативный метод компиляции"""
        try:
            print("[INFO] Использую альтернативный метод компиляции...")
            
            exe_name = "Factory Market"
            exe_path = os.path.join(install_path, f"{exe_name}.exe")
            
            # Создаем простой Python скрипт который работает
            simple_code = '''# -*- coding: utf-8 -*-
import sys
import os
import tkinter as tk
from tkinter import messagebox

def main():
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showinfo("Factory Market", 
                           "Factory Market успешно установлен!\\n\\n"
                           "Приложение готово к использованию.")
        root.destroy()
    except Exception as e:
        print(f"Ошибка: {e}")
        input("Нажмите Enter для выхода...")

if __name__ == "__main__":
    main()
'''
            
            simple_py = os.path.join(install_path, "_factory_market_simple.py")
            with open(simple_py, 'w', encoding='utf-8') as f:
                f.write(simple_code)
            
            # Пробуем скомпилировать простой EXE
            try:
                pyinstaller_args = [
                    sys.executable, "-m", "PyInstaller",
                    "--onefile",
                    "--windowed",
                    "--name", exe_name,
                    "--distpath", install_path,
                    "--clean",
                    "--noconfirm"
                ]
                
                # Добавляем иконку если есть
                install_icon = os.path.join(install_path, "icon.ico")
                if os.path.exists(install_icon):
                    pyinstaller_args.extend(["--icon", install_icon])
                
                pyinstaller_args.append(simple_py)
                
                result = subprocess.run(
                    pyinstaller_args,
                    capture_output=True,
                    text=True,
                    timeout=120
                )
                
                # Проверяем результат
                expected_exe = os.path.join(install_path, f"{exe_name}.exe")
                if os.path.exists(expected_exe):
                    print(f"[OK] Простой EXE создан: {expected_exe}")
                    # Удаляем временный файл
                    try:
                        os.remove(simple_py)
                    except:
                        pass
                    return expected_exe
            except Exception as e:
                print(f"[ERROR] Не удалось скомпилировать: {e}")
            
            # Если не получилось, создаем EXE через создание BAT
            return self.create_simple_exe(install_path)
            
        except Exception as e:
            print(f"[ERROR] Альтернативный метод тоже не сработал: {e}")
            return self.create_simple_exe(install_path)
    
    def create_simple_exe(self, install_path):
        """Создание простого EXE через создание BAT и преобразование в EXE"""
        try:
            print("[INFO] Создаю простой исполняемый файл...")
            
            # Создаем BAT файл с полезным сообщением
            bat_content = f'''@echo off
chcp 65001 >nul
title Factory Market
echo.
echo ========================================
echo Factory Market - Игровой лаунчер
echo ========================================
echo.
echo [УСПЕШНО УСТАНОВЛЕНО!]
echo.
echo Приложение установлено в:
echo {install_path}
echo.
echo Ярлык создан на рабочем столе.
echo.
echo Для запуска используйте ярлык "Factory Market" на рабочем столе.
echo.
echo Нажмите любую клавишу для выхода...
pause >nul
'''
            
            bat_path = os.path.join(install_path, "Factory Market.bat")
            with open(bat_path, 'w', encoding='utf-8') as f:
                f.write(bat_content)
            
            print(f"[INFO] Создан BAT файл: {bat_path}")
            
            # Преобразуем BAT в EXE (опционально, можно использовать Bat To Exe Converter)
            # Пока возвращаем BAT путь
            return bat_path
            
        except Exception as e:
            print(f"[ERROR] Не удалось создать простой EXE: {e}")
            return None
    
    def create_install_folders(self, install_path):
        os.makedirs(install_path, exist_ok=True)
        
        subfolders = [
            "image_cache",
            "screenshot_game", 
            "trailer_game",
            "logs",
            "games",
            "cache",
            "updates",
            "data",
            "config",
            "temp"
        ]
        
        for folder in subfolders:
            folder_path = os.path.join(install_path, folder)
            os.makedirs(folder_path, exist_ok=True)
            print(f"[OK] Создана папка: {folder}")
    
    def create_desktop_shortcut_func(self, exe_path, install_path, icon_path):
        """Создание ярлыка - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
        try:
            shortcut_path = os.path.join(self.desktop_path, "Factory Market.lnk")
            
            # Удаляем старые файлы
            if os.path.exists(shortcut_path):
                try:
                    os.remove(shortcut_path)
                    print(f"[INFO] Удален старый ярлык: {shortcut_path}")
                except:
                    pass
            
            # Проверяем что целевой файл существует
            if not os.path.exists(exe_path):
                print(f"[ERROR] Целевой файл не найден: {exe_path}")
                
                # Пробуем найти EXE в других местах
                possible_paths = [
                    os.path.join(install_path, "Factory Market.exe"),
                    os.path.join(install_path, "dist", "Factory Market.exe"),
                    os.path.join(install_path, "Factory Market.bat")
                ]
                
                for possible_path in possible_paths:
                    if os.path.exists(possible_path):
                        exe_path = possible_path
                        print(f"[INFO] Найден альтернативный файл: {exe_path}")
                        break
                else:
                    print("[ERROR] Не найден ни один исполняемый файл")
                    return False
            
            # Используем иконку
            install_icon = os.path.join(install_path, "icon.ico")
            if not os.path.exists(install_icon):
                install_icon = icon_path if icon_path else ""
            
            print(f"[INFO] Создаю ярлык для: {exe_path}")
            print(f"[INFO] Иконка: {install_icon}")
            print(f"[INFO] Рабочая папка: {install_path}")
            
            # Метод 1: Через VBScript
            vbs_content = f'''
Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = "{shortcut_path}"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "{exe_path}"
oLink.WorkingDirectory = "{install_path}"
oLink.IconLocation = "{install_icon}"
oLink.Description = "Factory Market - игровой лаунчер"
oLink.Save
'''
            
            vbs_file = os.path.join(install_path, "create_shortcut.vbs")
            with open(vbs_file, 'w', encoding='utf-8') as f:
                f.write(vbs_content)
            
            # Запускаем VBScript
            result = subprocess.run(
                ["cscript", "//B", "//Nologo", vbs_file],
                capture_output=True,
                text=True,
                shell=True
            )
            
            # Удаляем VBScript
            try:
                os.remove(vbs_file)
            except:
                pass
            
            # Проверяем результат
            if os.path.exists(shortcut_path):
                print(f"[OK] Ярлык создан: {shortcut_path}")
                
                # Проверяем что ярлык ссылается на правильный файл
                try:
                    check_script = os.path.join(install_path, "check_shortcut.vbs")
                    with open(check_script, 'w', encoding='utf-8') as f:
                        f.write(f'''
Set oWS = WScript.CreateObject("WScript.Shell")
Set oLink = oWS.CreateShortcut("{shortcut_path}")
WScript.Echo "Target: " & oLink.TargetPath
WScript.Echo "WorkingDir: " & oLink.WorkingDirectory
WScript.Echo "Icon: " & oLink.IconLocation
''')
                    
                    result = subprocess.run(
                        ["cscript", "//B", "//Nologo", check_script],
                        capture_output=True,
                        text=True,
                        shell=True
                    )
                    
                    try:
                        os.remove(check_script)
                    except:
                        pass
                    
                    print(f"[INFO] Проверка ярлыка:\n{result.stdout}")
                    
                except Exception as e:
                    print(f"[WARNING] Не удалось проверить ярлык: {e}")
                
                return True
            else:
                print(f"[ERROR] Ярлык не был создан: {result.stderr}")
                
                # Метод 2: Через создание BAT файла для создания ярлыка
                return self.create_desktop_shortcut_alternative(exe_path, install_path, icon_path)
                
        except Exception as e:
            print(f"[ERROR] Ошибка создания ярлыка: {e}")
            traceback.print_exc()
            return self.create_desktop_shortcut_alternative(exe_path, install_path, icon_path)
    
    def create_desktop_shortcut_alternative(self, exe_path, install_path, icon_path):
        """Альтернативный метод создания ярлыка"""
        try:
            shortcut_path = os.path.join(self.desktop_path, "Factory Market.lnk")
            
            # Создаем BAT файл который создает ярлык
            bat_content = f'''@echo off
chcp 65001 >nul
echo Создаю ярлык Factory Market...

REM Создаем VBS скрипт для создания ярлыка
echo Set oWS = WScript.CreateObject("WScript.Shell") > create_shortcut.vbs
echo sLinkFile = "{shortcut_path}" >> create_shortcut.vbs
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> create_shortcut.vbs
echo oLink.TargetPath = "{exe_path}" >> create_shortcut.vbs
echo oLink.WorkingDirectory = "{install_path}" >> create_shortcut.vbs
echo oLink.Description = "Factory Market - игровой лаунчер" >> create_shortcut.vbs
echo oLink.Save >> create_shortcut.vbs

cscript //B //Nologo create_shortcut.vbs
del create_shortcut.vbs

if exist "{shortcut_path}" (
    echo Ярлык успешно создан!
) else (
    echo Не удалось создать ярлык.
)
'''
            
            bat_file = os.path.join(install_path, "create_shortcut_alt.bat")
            with open(bat_file, 'w', encoding='utf-8') as f:
                f.write(bat_content)
            
            result = subprocess.run(
                [bat_file],
                capture_output=True,
                text=True,
                shell=True
            )
            
            try:
                os.remove(bat_file)
            except:
                pass
            
            if os.path.exists(shortcut_path):
                print(f"[OK] Ярлык создан альтернативным методом: {shortcut_path}")
                return True
            else:
                print(f"[ERROR] Альтернативный метод тоже не сработал")
                return False
                
        except Exception as e:
            print(f"[ERROR] Ошибка альтернативного метода: {e}")
            return False
    
    def create_start_menu_shortcut_func(self, exe_path, install_path, icon_path):
        """Создание ярлыка в меню 'Пуск'"""
        try:
            start_menu_path = os.path.join(os.environ['APPDATA'], 
                                          "Microsoft", "Windows", "Start Menu", 
                                          "Programs", "Factory Market")
            os.makedirs(start_menu_path, exist_ok=True)
            
            shortcut_path = os.path.join(start_menu_path, "Factory Market.lnk")
            
            install_icon = os.path.join(install_path, "icon.ico")
            if not os.path.exists(install_icon):
                install_icon = icon_path if icon_path else ""
            
            vbs_content = f'''
Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = "{shortcut_path}"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "{exe_path}"
oLink.WorkingDirectory = "{install_path}"
oLink.IconLocation = "{install_icon}"
oLink.Description = "Factory Market - игровой лаунчер"
oLink.Save
'''
            
            vbs_file = os.path.join(install_path, "create_startmenu_shortcut.vbs")
            with open(vbs_file, 'w', encoding='utf-8') as f:
                f.write(vbs_content)
            
            result = subprocess.run(["cscript", "//B", "//Nologo", vbs_file], 
                                  capture_output=True, text=True, shell=True)
            
            try:
                os.remove(vbs_file)
            except:
                pass
            
            if os.path.exists(shortcut_path):
                print("[OK] Создан ярлык в меню Пуск")
                return True
            else:
                print(f"[ERROR] Не удалось создать ярлык в меню Пуск: {result.stderr}")
                return False
                
        except Exception as e:
            print(f"[WARNING] Ошибка создания ярлыка в меню 'Пуск': {e}")
            return False
    
    def create_uninstaller_func(self, install_path, exe_path):
        uninstaller_content = f'''@echo off
chcp 65001 >nul
title Factory Market - Удаление
echo.
echo ========================================
echo Factory Market - Удаление приложения
echo ========================================
echo.

set /p choice="Вы уверены, что хотите удалить Factory Market? (y/n): "

if /i "%choice%"=="y" (
    echo.
    echo Удаляю приложение...
    
    del "{self.desktop_path}\\Factory Market.lnk" 2>nul
    rmdir /s /q "{install_path}" 2>nul
    rmdir /s /q "%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Factory Market" 2>nul
    
    reg delete "HKEY_CURRENT_USER\\Software\\FactoryMarket" /f 2>nul
    reg delete "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\FactoryMarket" /f 2>nul
    
    echo.
    echo [OK] Factory Market успешно удален!
    echo.
) else (
    echo.
    echo Удаление отменено.
    echo.
)

pause
'''
        
        uninstaller_path = os.path.join(install_path, "Удалить Factory Market.bat")
        with open(uninstaller_path, 'w', encoding='utf-8') as f:
            f.write(uninstaller_content)
        
        print(f"[OK] Создан деинсталлятор: {uninstaller_path}")
    
    def register_in_registry(self, install_path, exe_path, desktop_shortcut_created):
        try:
            key_path = r"Software\FactoryMarket"
            key = reg.CreateKey(reg.HKEY_CURRENT_USER, key_path)
            reg.SetValueEx(key, "InstallPath", 0, reg.REG_SZ, install_path)
            reg.SetValueEx(key, "ExePath", 0, reg.REG_SZ, exe_path)
            reg.SetValueEx(key, "Version", 0, reg.REG_SZ, self.app_version)
            reg.SetValueEx(key, "InstallDate", 0, reg.REG_SZ, 
                          datetime.datetime.now().strftime("%Y-%m-%d"))
            reg.SetValueEx(key, "DesktopShortcut", 0, reg.REG_DWORD, 1 if desktop_shortcut_created else 0)
            reg.CloseKey(key)
            
            print("[OK] Записано в реестр HKCU")
            
            try:
                uninstall_path = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\FactoryMarket"
                key = reg.CreateKey(reg.HKEY_LOCAL_MACHINE, uninstall_path)
                reg.SetValueEx(key, "DisplayName", 0, reg.REG_SZ, "Factory Market")
                reg.SetValueEx(key, "DisplayVersion", 0, reg.REG_SZ, self.app_version)
                reg.SetValueEx(key, "Publisher", 0, reg.REG_SZ, self.publisher)
                reg.SetValueEx(key, "UninstallString", 0, reg.REG_SZ, 
                             f'"{install_path}\\Удалить Factory Market.bat"')
                reg.SetValueEx(key, "InstallLocation", 0, reg.REG_SZ, install_path)
                reg.SetValueEx(key, "NoModify", 0, reg.REG_DWORD, 1)
                reg.SetValueEx(key, "NoRepair", 0, reg.REG_DWORD, 1)
                reg.SetValueEx(key, "EstimatedSize", 0, reg.REG_DWORD, 100)
                reg.CloseKey(key)
                
                print("[OK] Записано в реестр HKLM")
                
            except Exception as e:
                print(f"[WARNING] Нет прав на запись в HKLM: {e}")
            
        except Exception as e:
            print(f"[WARNING] Не удалось записать в реестр: {e}")
    
    def show_success_message(self, install_path, exe_path, desktop_shortcut_created):
        message = f"""
        УСТАНОВКА ЗАВЕРШЕНА!
        
        Factory Market успешно установлен!
        
        Что было установлено:
        1. Полная установка в папке:
           {install_path}
        
        2. Ярлык на рабочем столе: Factory Market.lnk
           (ссылается на: {os.path.basename(exe_path)})
        
        3. Исполняемый файл:
           {exe_path}
        
        Для запуска:
        • Дважды щелкните ЯРЛЫК "Factory Market.lnk" на рабочем столе
        • ИЛИ запустите файл "Factory Market.exe" в папке установки
        
        Для удаления:
        • Запустите "Удалить Factory Market.bat" в папке установки
        
        Приложение готово к использованию!
        
        Запустить Factory Market сейчас?
        """
        
        if messagebox.askyesno("Установка завершена", message):
            desktop_shortcut = os.path.join(self.desktop_path, "Factory Market.lnk")
            if desktop_shortcut_created and os.path.exists(desktop_shortcut):
                try:
                    print(f"[INFO] Запускаю ярлык: {desktop_shortcut}")
                    os.startfile(desktop_shortcut)
                    print("[OK] Запущено через ярлык")
                except Exception as e:
                    print(f"Ошибка запуска через ярлык: {e}")
                    
                    if os.path.exists(exe_path):
                        try:
                            os.startfile(exe_path)
                            print("[OK] Запущено через EXE")
                        except Exception as e2:
                            print(f"Ошибка запуска EXE: {e2}")
            elif os.path.exists(exe_path):
                try:
                    os.startfile(exe_path)
                    print("[OK] Запущено через EXE")
                except Exception as e:
                    print(f"Ошибка запуска EXE: {e}")
        
        self.root.destroy()
    
    def show_error_message(self, error_msg):
        messagebox.showerror("Ошибка установки",
                           f"Произошла ошибка при установке:\n\n{error_msg}\n\n"
                           "Пожалуйста, попробуйте снова.")
        self.progress_var.set("Ошибка установки")
        self.install_button.config(state="normal")
    
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    print("Запуск установщика Factory Market...")
    print("=" * 50)
    
    installer_dir = os.path.dirname(os.path.abspath(__file__))
    source_file = os.path.join(installer_dir, "Game_Launcher.py")
    
    if not os.path.exists(source_file):
        print(f"[WARNING] Исходный файл не найден: {source_file}")
        print("[INFO] Установщик продолжит работу, но потребует исходный файл для компиляции")
    else:
        print(f"[OK] Исходный файл найден: {source_file}")
        file_size = os.path.getsize(source_file) / 1024
        print(f"[INFO] Размер исходного кода: {file_size:.1f} KB")
    
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    print(f"[INFO] Ярлык будет создан на рабочем столе: {desktop}\\Factory Market.lnk")
    print("[INFO] Ярлык будет ссылаться на скомпилированный EXE файл")
    print("[INFO] Для успешной установки убедитесь, что:")
    print("[INFO] 1. Python установлен и добавлен в PATH")
    print("[INFO] 2. У вас есть права администратора")
    print("[INFO] 3. Файл Game_Launcher.py находится в той же папке")
    
    installer = FactoryMarketInstaller()
    installer.run()