# build.py - скрипт для создания EXE
import subprocess
import sys

def build_exe():
    # Команда для PyInstaller с оптимизациями
    command = [
        'pyinstaller',
        '--onefile',
        '--noconsole',
        '--name=Game_Launcher',
        '--clean',
        '--noupx',  # UPX иногда увеличивает размер
        '--exclude-module=tkinter',
        '--exclude-module=matplotlib',
        '--exclude-module=pandas',
        '--exclude-module=numpy',
        '--exclude-module=scipy',
        '--exclude-module=requests',  # Если заменили на urllib
        '--hidden-import=PyQt5.sip',
        '--add-data=image_cache;image_cache',
        '--add-data=screenshot_game;screenshot_game',
        '--add-data=trailer_game;trailer_game',
        'Game_Launcher.py'  # Ваш основной файл
    ]
    
    subprocess.run(command)

if __name__ == "__main__":
    build_exe()